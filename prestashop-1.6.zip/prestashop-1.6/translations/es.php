<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{waiap}prestashop>waiap_7ec973a716fad72c016c377b52f155fa'] = 'Pago con tarjeta y otros métodos de pago';
$_MODULE['<{waiap}prestashop>waiap_bacb0af80c1629a4a31550c26c25d637'] = 'Con el Payment Wall de Waiap puedes aceptar múltiples formas de pago (Tarjetas Visa, MasterCard, Amazon Pay, PayPal, Google Pay, Apple Pay, Bizum, pago con Cuenta y pago con Financiación) en un único módulo';
$_MODULE['<{waiap}prestashop>waiap_a02758d758e8bec77a33d7f392eb3f8a'] = 'No se ha especificado una moneda para este módulo.';
$_MODULE['<{waiap}prestashop>waiap_fe5d926454b6a8144efce13a44d019ba'] = 'Valor de configuración inválido';
$_MODULE['<{waiap}prestashop>waiap_c888438d14855d7d96a2724ee9c306bd'] = 'Ajustes actualizados';
$_MODULE['<{waiap}prestashop>waiap_4c8c41328964a7b7d540d97ad9f273e8'] = 'Ajustes de Waiap (El muro de pagos)';
$_MODULE['<{waiap}prestashop>waiap_9b64ccb1432937ff15de4ebf2348ea00'] = 'Enviroment';
$_MODULE['<{waiap}prestashop>waiap_897356954c2cd3d41b221e3f24f99bba'] = 'Key';
$_MODULE['<{waiap}prestashop>waiap_1e6947ac7fb3a9529a9726eb692c8cc5'] = 'Secret';
$_MODULE['<{waiap}prestashop>waiap_be8545ae7ab0276e15898aae7acfbd7a'] = 'Resource';
$_MODULE['<{waiap}prestashop>waiap_ff162fce740b5c9e9c30a5de95022c22'] = 'Nombre mostrado';
$_MODULE['<{waiap}prestashop>waiap_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{waiap}prestashop>waiap_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver al listado';
$_MODULE['<{waiap}prestashop>waiap_bfb10b1934930a566a97af42e5a7d1f7'] = 'Hubo un error al procesar su pago. Por favor, inténtelo de nuevo.';
$_MODULE['<{waiap}prestashop>paymentwall_return_e72f5db7df95fb92f69e9b5ac76f05fe'] = 'Tu pedido %s está completado';
$_MODULE['<{waiap}prestashop>paymentwall_app_5f1ce190f406a148ac4420af8ca753f3'] = 'Por favor, asegúrese de haber aceptado los términos y condiciones.';
